package com.koujousen.plugin.koujousenplugin;

public enum TeamType {
    RED,BLUE
}
